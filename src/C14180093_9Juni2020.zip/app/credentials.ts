export const firebaseConfig = {
    apiKey: "AIzaSyAW0yG2cT9l_-tCKL3O8rGMO0kAu1K3k5k",
    authDomain: "ioniclata-3ec08.firebaseapp.com",
    databaseURL: "https://ioniclata-3ec08.firebaseio.com",
    projectId: "ioniclata-3ec08",
    storageBucket: "ioniclata-3ec08.appspot.com",
    messagingSenderId: "990128905731",
    appId: "1:990128905731:web:f9050c8dd7c9e9c0e67836",
    measurementId: "G-78LDFGYK3S"
  };