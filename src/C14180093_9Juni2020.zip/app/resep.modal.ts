export interface Resep{
    idresep : string;
    imgresep : string;
    namaresep : string;
    deskripsi : string;
    waktu : string;
}